/*
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE', which is part of this source code package.
 * Tuan PM <tuanpm at live dot com>
 */
#ifndef _PLATFORM_H__
#define _PLATFORM_H__

//Support ESP32
#ifdef ESP_PLATFORM
#include "platform_esp32_idf.h"
#endif

#endif
